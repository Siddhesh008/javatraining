package com.example.demosecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
