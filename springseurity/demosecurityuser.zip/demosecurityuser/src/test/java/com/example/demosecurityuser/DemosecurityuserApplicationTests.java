package com.example.demosecurityuser;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemosecurityuserApplicationTests {

	@Test
	void contextLoads() {
	}

}
