package com.example.demoassign2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Demoassign2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
