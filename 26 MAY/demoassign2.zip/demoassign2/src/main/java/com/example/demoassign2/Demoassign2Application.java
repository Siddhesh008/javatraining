package com.example.demoassign2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demoassign2Application {

	public static void main(String[] args) {
		SpringApplication.run(Demoassign2Application.class, args);
	}

}
