package com.example.demoasg1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Demoasg1Application {

	public static void main(String[] args) {
		SpringApplication.run(Demoasg1Application.class, args);
	}

}
